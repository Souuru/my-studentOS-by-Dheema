# Deploying StudentOS in UTM (macOS)

UTM (https://mac.getutm.app) runs QEMU under the hood and is free. This
guide covers two stages: (1) a development VM you use while building
StudentOS, and (2) booting your finished custom `.iso`.

## 1. Development VM (Arch Linux, Apple Silicon or Intel)

1. Download the **Arch Linux ARM** ISO (Apple Silicon) or **Arch Linux x86_64**
   ISO (Intel Mac), from archlinux.org.
2. In UTM: **Create a New VM → Virtualize** (not Emulate — virtualization is
   much faster and is what you want for Apple Silicon).
3. Settings:
   - Architecture: match your Mac (ARM64 for M1/M2/M3, x86_64 for Intel)
   - Memory: 4096 MB minimum, 8192 MB recommended
   - CPU cores: 2–4
   - Storage: 30–40 GB (QCOW2, dynamically allocated is fine)
   - Display: enable "GPU Acceleration" for a usable GNOME experience
4. Boot the ISO, follow the Arch install guide (`archinstall` script makes
   this much easier — choose GNOME as the desktop profile).

## 2. Shared folder between macOS and the VM

UTM supports **VirtFS (9p)** shared directories:

1. In the VM's UTM settings → **Sharing** tab, set "Shared Directory" to a
   folder on your Mac (e.g. `~/StudentOS-dev`).
2. Inside the Linux VM:
   ```bash
   sudo mkdir -p /mnt/mac-share
   sudo mount -t 9p -o trans=virtio,version=9p2000.L share /mnt/mac-share
   ```
3. To make this permanent, add to `/etc/fstab`:
   ```
   share  /mnt/mac-share  9p  trans=virtio,version=9p2000.L,rw,_netdev  0  0
   ```

Now you can edit StudentOS source code in a macOS editor (e.g. VS Code) and
build/run it inside the Linux VM via `/mnt/mac-share`.

## 3. Auto-start StudentOS apps on login

Once `studentos-notes` is built (an `.AppImage`, `.deb`, or installed via
`stud install`), add a GNOME **autostart** entry so it opens automatically:

```bash
mkdir -p ~/.config/autostart
cat > ~/.config/autostart/studentos-notes.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=StudentOS Notes
Exec=/usr/local/bin/studentos-notes
X-GNOME-Autostart-enabled=true
EOF
```

For a full **system-wide** auto-login + auto-start (e.g. for a shared lab
machine), enable GDM autologin:

```bash
sudo mkdir -p /etc/gdm
cat > /etc/gdm/custom.conf <<'EOF'
[daemon]
AutomaticLoginEnable=true
AutomaticLogin=student
EOF
```

## 4. Booting your finished StudentOS `.iso`

1. After running `scripts/build-iso.sh`, you'll have an `.iso` in
   `build/_out/`.
2. In UTM: **Create a New VM → Virtualize → Linux**, point "Boot ISO Image"
   at your StudentOS `.iso`.
3. Boot — you should land on the GDM login screen with the StudentOS dark
   theme and wallpaper.
4. To **install to disk** (not just run live), the releng profile includes
   the Arch installer / `archinstall`; run it from the live session.
5. After install, reboot the VM without the ISO attached (UTM → eject CD
   image) to boot from the virtual disk.

## 5. Performance tips

- Use **VirtIO** drivers for disk and network (default in UTM's
  "Virtualize" mode) — much faster than emulated IDE.
- Keep the LLM model small (`phi3` or `gemma2:2b`, ~2GB) — running larger
  models inside a VM on a laptop will be slow.
- If GNOME feels heavy in the VM, the same ISO can swap GNOME for a lighter
  desktop (e.g. Xfce) by editing `build/archiso/packages.x86_64`.
