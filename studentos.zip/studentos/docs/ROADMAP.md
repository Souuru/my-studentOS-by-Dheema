# StudentOS — Future Roadmap

This roadmap is ordered from "next, realistic" to "ambitious / research
project" so you can stop at whatever point fits your timeline.

## v0.1 — Foundation (covered by this repo)
- [x] Architecture + repo layout
- [x] `stud` package manager CLI (Rust, wraps pacman/apt + flatpak)
- [x] `studentos-notes`: Markdown notes, flashcards, planner (Tauri+React+SQLite)
- [x] archiso build profile + custom theme hooks
- [x] UTM deployment guide

## v0.2 — Complete the productivity suite
- [ ] Citation manager tab (BibTeX import/export, DOI lookup via Crossref API)
- [ ] PDF reader tab using `pdf.js`, with highlight/annotation stored in SQLite
- [ ] "Ask AI" panel wired to local `ollama` for summarization & code explanation
- [ ] GNOME Shell extension: "Study Mode" toggle (DND + app blocking)

## v0.3 — Multi-user & classroom features
- [ ] Per-user data isolation testing (multiple accounts on one StudentOS install)
- [ ] `stud-sandbox`: Rust service for running student code in `bwrap` + cgroups
- [ ] Optional "shared notes" mode using a local Syncthing/Nextcloud setup
- [ ] Admin script for provisioning a lab of machines from one custom ISO

## v0.4 — AI-native features
- [ ] RAG over a student's own notes/PDFs (local embeddings + SQLite vector search,
      e.g. via `sqlite-vss`)
- [ ] "Explain this error" — hook into terminal output for programming environment
- [ ] Flashcard auto-generation from notes using the local LLM

## v0.5 — Going deeper into "real OS" territory (optional/advanced)
- [ ] Custom kernel config: build a minimal `linux-studentos` kernel package
      (trim unused drivers, enable cgroups v2 / namespaces explicitly) —
      this is the piece that lets you say "I configured a custom Linux
      kernel" with confidence, without it being a prerequisite for
      everything above
- [ ] Immutable/atomic updates (OSTree or similar) for lab deployments
- [ ] ARM build for Raspberry Pi (cheap classroom hardware)

## Stretch goals
- [ ] Package `stud`, `studentos-notes` etc. as proper Arch packages
      (PKGBUILD + local repo) so `stud install studentos-notes` works
      on a vanilla Arch install too
- [ ] Web-based "try StudentOS" demo using a WASM build of the notes app
- [ ] Community package repo for student-made study tools
