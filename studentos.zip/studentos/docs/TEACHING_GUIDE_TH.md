# คู่มือศึกษาและลงมือทำ StudentOS ด้วยตัวเอง (ฉบับละเอียด)

> เป้าหมาย: ทำให้โปรเจกต์นี้ **เล็กพอที่คนคนเดียวทำได้จริงใน 1 เทอม** แต่ยัง
> ได้ครบทุก concept ที่โจทย์ต้องการ (kernel, services, sandbox, GUI,
> package manager, AI)

---

## ภาพรวมก่อนเริ่ม: เราจะ "ไม่" เขียน OS ใหม่ทั้งหมด

สิ่งที่ดูเหมือนยากที่สุดในโจทย์ — "Linux kernel based, modular services,
sandbox, multi-user" — **มีอยู่แล้วใน Linux kernel** เราไม่ต้องเขียน kernel
ใหม่ (การคอมไพล์ kernel เองคือ optional ตอนท้าย ไม่ใช่จุดเริ่ม)

แนวทางที่ทำได้จริงคือ **"Linux distro respin"** — เอา distro ที่มีอยู่
(Arch Linux) มาปรับแต่ง ใส่ theme, ใส่โปรแกรมของเราเอง, แล้วทำเป็น `.iso`
ไฟล์เดียวที่ติดตั้งได้ — นี่คือวิธีที่ Manjaro, SteamOS, Kali Linux ฯลฯ
ทำจริง ๆ

โปรเจกต์ของน้องจะแบ่งเป็น **3 ส่วนที่แยกกันทำได้**:

1. **ตัวระบบ (distro)** — ใช้ของเดิม + theme + script
2. **โปรแกรมของเราเอง** — `stud` CLI (Rust), Notes app (Tauri+React)
3. **AI** — ใช้ ollama (โมเดลสำเร็จรูป) ต่อกับแอปของเรา

---

## เตรียมเครื่อง

- macOS เครื่องเดิมของน้อง + **UTM** (ฟรี, จาก App Store หรือ
  https://mac.getutm.app)
- สร้าง VM แบบ **Arch Linux** หรือถ้าอยากง่ายขึ้นช่วงแรกใช้ **Ubuntu/Debian**
  ก่อน (เปลี่ยนเป็น Arch ตอนทำ custom ISO จริง)
- RAM ให้ VM อย่างน้อย 4GB, disk 30GB+

---

## Phase 0 (1 สัปดาห์): ปูพื้น Linux ที่ต้องรู้

ถ้าน้องยังไม่คุ้น command line ให้เริ่มที่นี่ก่อน ไม่งั้น phase ถัดไปจะงง

สิ่งที่ต้องทำให้คล่อง:
- `ls, cd, cp, mv, rm, mkdir, chmod, chown` — จัดการไฟล์/permission
- `apt`/`pacman` — ติดตั้งโปรแกรม (นี่คือสิ่งที่ `stud` จะไป wrap)
- `systemctl status/start/enable` — ดู/คุม service
- `ps, top, kill` — ดู process (เกี่ยวกับ process isolation)
- เขียน bash script ง่าย ๆ (`#!/bin/bash`, if, for, function)

**แหล่งเรียน**: "The Linux Command Line" (หนังสือฟรี, William Shotts) —
อ่านแค่บท 1–15 ก็พอ

**Checkpoint**: ติดตั้ง Ubuntu บน UTM ได้เอง, สร้าง user ใหม่ได้,
`sudo apt install neofetch` ได้

---

## Phase 1 (1–2 สัปดาห์): เข้าใจโครงสร้าง Linux ที่ใช้ทำ "multi-user / isolation"

ไม่ต้องเขียนโค้ด แค่ "ทดลองและสังเกต" ใน VM:

1. สร้าง user ใหม่ 2 คน (`sudo useradd -m student2`)
   → สังเกตว่าแต่ละคนมี `/home/<user>` แยกกัน, สิทธิ์เข้าไฟล์กันไม่ได้
2. ลองรัน `systemd-run --scope -p MemoryMax=100M bash -c 'ls'`
   → นี่คือหัวใจของ "process isolation / resource limit" ที่โจทย์ขอ
3. ติดตั้ง `firejail` (`sudo apt install firejail`) แล้วลอง
   `firejail firefox` → สังเกตว่า firefox มองไม่เห็นไฟล์ทั้งหมดในเครื่อง
   → นี่คือ "secure sandbox execution"

**ทำไม phase นี้สำคัญ**: เป็นการพิสูจน์ให้ตัวเองเห็นว่า requirement
ข้อ 3 (architecture/security) ของโจทย์ **ทำงานอยู่แล้วโดย kernel**
งานของเราคือ "เรียกใช้มันให้สวยและง่ายขึ้น" ไม่ใช่สร้างใหม่

---

## Phase 2 (2–3 สัปดาห์): เขียน `stud` — package manager CLI ด้วย Rust

นี่คือโปรแกรม Rust ตัวแรกของโปรเจกต์ และเป็น "ของจริง" ที่ใช้งานได้

### ติดตั้ง Rust
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

### โครงสร้างโปรแกรม (มีโค้ดเริ่มต้นให้แล้วใน `tools/stud-pkg/`)

แนวคิด:
- `stud search <pkg>` → เรียก `apt-cache search <pkg>` (หรือ `pacman -Ss`)
  แล้ว parse output มาแสดงผลให้สวยกว่า
- `stud install <pkg>` → เรียก `sudo apt install -y <pkg>`
- `stud remove <pkg>` → เรียก `sudo apt remove -y <pkg>`
- `stud update` → เรียก `sudo apt update && sudo apt upgrade -y`

ใน Rust ใช้ `std::process::Command` ในการเรียกคำสั่งระบบ — ไม่ต้องใช้
library ภายนอกเลยสำหรับเวอร์ชันแรก (compile ได้แม้ไม่มีเน็ต)

**สิ่งที่น้องจะได้เรียน**: argument parsing, error handling (`Result`,
`?` operator), การเรียก external process, การจัดข้อความ output

**Checkpoint**: รัน `stud search vim`, `stud install cowsay`,
`stud remove cowsay` ได้จริงบน Ubuntu VM

ดูโค้ดตัวอย่างเต็ม ๆ ได้ใน `tools/stud-pkg/src/main.rs` (compile แล้ว
ใน repo นี้พร้อมใช้งาน — `cargo build --release`)

---

## Phase 3 (2 สัปดาห์): ปรับแต่ง Desktop ให้เป็น "StudentOS"

ใช้ **GNOME** (มาพร้อม Ubuntu) เพราะ docs เยอะ, theme ง่าย

1. ติดตั้ง GNOME Tweaks: `sudo apt install gnome-tweaks gnome-shell-extensions`
2. โหลด dark theme เช่น **Orchis** หรือ **WhiteSur-Dark** จาก GitHub
3. เปลี่ยน wallpaper, ไอคอน, ฟอนต์ (เช่น Inter, JetBrains Mono สำหรับ code)
4. เปิด extension "Search light" หรือใช้ GNOME Activities (กด Super key)
   เป็น search launcher อยู่แล้ว — ไม่ต้องเขียนใหม่
5. ลองเขียน **GNOME Shell extension เล็ก ๆ** ของตัวเอง — เช่นปุ่ม "Study
   Mode" ที่กดแล้วเปิด Do Not Disturb (extension คือไฟล์ JS + JSON ไม่กี่
   ไฟล์ มี template ให้ใน https://gjs.guide)

**Checkpoint**: เปิด VM มาแล้วหน้าตาเหมือน "ระบบของตัวเอง" ไม่ใช่ Ubuntu
ปกติ มี wallpaper/theme ของ StudentOS

---

## Phase 4 (3–4 สัปดาห์): สร้างแอป Notes/Flashcards ด้วย Tauri + React

นี่คือส่วนที่ใหญ่สุด แต่แบ่งเป็นชิ้นเล็ก ๆ ได้

### ติดตั้งเครื่องมือ
```bash
sudo apt install nodejs npm
cargo install create-tauri-app
```

### โครงสร้าง (ดู `apps/studentos-notes/` ใน repo)
- `src/` → React frontend (UI)
- `src-tauri/` → Rust backend (เข้าถึงไฟล์, SQLite)
- ใช้ library `rusqlite` (Rust) สำหรับ SQLite

### แบ่งทำเป็น milestone:
1. **Markdown notes**: textarea + แสดงผล markdown (ใช้ library
   `react-markdown`) + บันทึกลง SQLite
2. **Flashcards**: หน้า "สร้าง deck" + หน้า "ทบทวน" แบบ flip card +
   เก็บ schedule แบบ spaced repetition (อัลกอริทึม SM-2 — สูตรง่าย ๆ
   ไม่กี่บรรทัด)
3. **Assignment tracker / Study planner**: ตาราง todo + due date,
   query SQLite ด้วย `WHERE due_at < datetime('now', '+3 days')`
   สำหรับ "งานที่ใกล้ครบกำหนด"
4. **Citation manager**: ฟอร์มกรอก ชื่อผู้แต่ง/ปี/ชื่อบทความ →
   generate BibTeX string (string formatting ธรรมดา ไม่ต้องใช้ library)

**Checkpoint แต่ละ milestone**: แอป run ได้ด้วย `npm run tauri dev`,
บันทึก/โหลดข้อมูลจาก SQLite ได้จริง ปิดเปิดแอปข้อมูลไม่หาย

---

## Phase 5 (2 สัปดาห์): PDF Reader + Research/AI Assistant

### PDF reader
- ใช้ library `pdf.js` (JavaScript) ฝังใน React component — render PDF
  ได้โดยไม่ต้องเขียน parser เอง

### Local AI (ollama)
```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull phi3        # โมเดลเล็ก ~2GB เหมาะกับ VM
ollama serve            # รันเป็น service ที่ localhost:11434
```

### เชื่อมแอปกับ AI
- ใน React: `fetch("http://localhost:11434/api/generate", {...})`
- ฟีเจอร์ที่ทำได้ง่าย:
  - **สรุป PDF**: เอาข้อความจาก PDF (ใช้ `pdf.js` ดึง text) →
    ส่งไปพร้อม prompt "สรุปเนื้อหานี้เป็นภาษาไทย 5 bullet"
  - **อธิบายโค้ด**: ส่งโค้ดที่เลือก + prompt "อธิบายโค้ดนี้ทำอะไร"
  - **สรุปงานวิจัย**: เหมือน PDF summarization แต่ prompt เน้น
    methodology/results

**Checkpoint**: เลือกข้อความใน PDF → กดปุ่ม "สรุปด้วย AI" → ได้คำตอบจาก
ollama จริงแสดงใน UI

---

## Phase 6 (1–2 สัปดาห์): ประกอบทุกอย่างเป็น Custom ISO

ตอนนี้ค่อยย้ายจาก Ubuntu VM ไปทำ **Arch + archiso** (เพราะ archiso เป็น
เครื่องมือทำ custom ISO ที่เบาและจัด config ง่ายที่สุด)

```bash
# บนเครื่อง Arch Linux (อาจทำใน VM แยกอีกตัว หรือ container)
sudo pacman -S archiso
cp -r /usr/share/archiso/configs/releng/ studentos-iso
# แก้ studentos-iso/packages.x86_64 → เพิ่ม gnome, ollama, อื่น ๆ
# ใส่ไฟล์ของเรา (stud binary, notes app .deb/.AppImage, theme)
# ลง airootfs/etc/skel/ (ไฟล์ default ที่ user ใหม่จะได้รับ)
sudo mkarchiso -v -w work/ -o out/ studentos-iso/
```

ผลลัพธ์: ไฟล์ `.iso` ที่บูตขึ้นมาแล้วมี GNOME + theme + `stud` +
StudentOS apps ติดตั้งมาให้พร้อม

ดู template ที่เตรียมไว้ใน `build/archiso/`

**Checkpoint**: บูต `.iso` นี้ใน UTM แล้วเห็นหน้าจอ StudentOS
ครบทุกแอปที่ทำมา

---

## Phase 7 (ต่อเนื่อง): Multi-user + Sandbox สำหรับ "รันโค้ดนักเรียน"

ถ้าโปรแกรมมิ่งสภาพแวดล้อมต้องการ "run code ของผู้ใช้แบบปลอดภัย" (เช่น
ระบบช่วยตรวจโค้ดของเพื่อน ๆ):

```bash
systemd-run --scope -p MemoryMax=256M -p CPUQuota=50% \
  bwrap --ro-bind /usr /usr --ro-bind /lib /lib \
        --proc /proc --dev /dev --unshare-net --unshare-pid \
        --chdir /tmp \
        python3 /path/to/student_code.py
```

เขียน Rust service เล็ก ๆ (`stud-sandbox`) ที่รับโค้ด → เขียนลง temp file
→ รันคำสั่งข้างบน → ส่ง stdout/stderr กลับ — นี่คือ "process isolation"
และ "secure sandbox execution" ในโจทย์แบบที่ใช้งานได้จริง

---

## ลำดับเวลาที่แนะนำ (รวม ~3–4 เดือน, เรียนไปด้วยทำไปด้วย)

| สัปดาห์ | งาน |
|---|---|
| 1 | Phase 0: Linux basics |
| 2 | Phase 1: multi-user/isolation experiments |
| 3–5 | Phase 2: `stud` CLI (Rust) |
| 6–7 | Phase 3: Desktop theme |
| 8–11 | Phase 4: Notes/Flashcards/Planner app |
| 12–13 | Phase 5: PDF + AI |
| 14–15 | Phase 6: Custom ISO |
| 16+ | Phase 7: Sandbox + polish + roadmap items |

ทำได้แค่บางเฟสก็ยังเป็นโปรเจกต์ที่โชว์ได้ — เช่นถ้าทำแค่ Phase 0–4 ก็ได้
"แอปนักเรียนของตัวเองที่รันบน Linux ที่ปรับแต่งเอง" ซึ่งก็เพียงพอมากแล้ว

---

## แหล่งเรียนเพิ่มเติม (ฟรีทั้งหมด)

- **Rust**: "The Rust Book" (rust-lang.org/book) — อ่านบท 1–10 พอสำหรับ
  `stud-pkg`
- **Tauri**: tauri.app/v1/guides — มี tutorial ทำแอปแรกแบบ step-by-step
- **archiso**: Arch Wiki "Archiso" page — ตัวอย่าง config ครบ
- **GNOME extension**: gjs.guide/extensions
- **Linux sandboxing**: man page ของ `bwrap`, `systemd-run`
- **ollama**: ollama.com/library — ดูโมเดลที่รันบน RAM น้อยได้ (phi3, gemma2:2b)
