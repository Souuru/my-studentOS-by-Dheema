# StudentOS — Architecture

## 1. Layer diagram

```
┌──────────────────────────────────────────────────────────────────┐
│  Desktop Environment (GNOME Shell + custom "StudentOS Dark" theme) │
│  - Window manager (Mutter)                                          │
│  - Search launcher (GNOME Activities Overview)                      │
│  - Notification center (GNOME Shell)                                │
├──────────────────────────────────────────────────────────────────┤
│  Application Layer (Tauri + React, SQLite-backed)                  │
│  - studentos-notes   (Markdown notes, flashcards, planner)         │
│  - studentos-papers  (PDF reader + citation manager)               │
│  - studentos-ai      (chat UI for local LLM, summarization)        │
│  - studentos-code    (links to VS Code / Zed, pre-configured)      │
├──────────────────────────────────────────────────────────────────┤
│  System Services (Rust binaries, run as systemd units)             │
│  - stud-pkg     → package manager CLI (wraps pacman + flatpak)     │
│  - stud-aid     → local LLM gateway (talks to ollama over HTTP)    │
│  - stud-sandbox → launches user code in systemd-nspawn / bwrap     │
│  - stud-sync    → optional sync of notes/flashcards across devices │
├──────────────────────────────────────────────────────────────────┤
│  Base OS (Arch Linux)                                               │
│  - systemd (init, services, user sessions)                         │
│  - pacman (real package manager underneath `stud`)                 │
│  - polkit (permission prompts)                                       │
│  - Flatpak + bubblewrap (sandboxed 3rd-party apps)                  │
├──────────────────────────────────────────────────────────────────┤
│  Linux Kernel (stock, LTS) — multi-user, process isolation,        │
│  namespaces, cgroups — all the "modular / isolation" requirements  │
│  already live here, we just configure them                          │
└──────────────────────────────────────────────────────────────────┘
```

## 2. Why this mapping is "real OS engineering," not a cop-out

Every production Linux distro is a *respin*. Ubuntu is Debian + GNOME +
branding. SteamOS is Arch + KDE + Valve tooling. The skill you actually
practice — kernel config, init systems, package management, sandboxing,
service design, packaging your own apps — is **identical** whether or not
you compile `vmlinux` yourself. Compiling your own kernel is a *separate,
optional* exercise (covered in the roadmap) that you can bolt on later
without changing anything else.

## 3. Multi-user & permissions

- Each student gets a standard Linux user account (`useradd`).
- `wheel` group → sudo access (for instructors/admins only).
- Per-user app data lives in `~/.local/share/studentos/*.db` (SQLite).
- `polkit` rules restrict which actions need a password (installing
  packages, mounting drives) vs. which are free (running sandboxed code).

## 4. Secure sandbox execution (for student programming exercises)

Two layers, increasing isolation:

1. **Flatpak** for GUI apps (PDF reader, browser) — sandboxed via
   bubblewrap automatically, no extra work needed.
2. **`stud-sandbox`** (custom Rust service) — for "run my code" features in
   the programming environment:
   - Spawns `systemd-run --scope -p ... bwrap --ro-bind /usr /usr --tmpfs /tmp ...`
   - CPU/memory limits via cgroups v2 (`MemoryMax=`, `CPUQuota=`)
   - No network namespace by default (`--unshare-net`)
   - This is the same technique used by online judges (e.g. competitive
     programming graders) and Jupyter-based teaching platforms.

## 5. AI Assistant / Local LLM

- `ollama` runs as a systemd service, serving models like `llama3.2:3b` or
  `phi3` (small enough for a student laptop, ~2–4GB RAM).
- `stud-aid` (Rust) is a thin proxy: receives requests from apps over a Unix
  socket, forwards to `http://localhost:11434`, adds prompt templates for:
  - **PDF summarization** — extract text with `pdftotext`, chunk, summarize
  - **Code explanation** — wraps selected code with a "explain this" prompt
  - **Research summarization** — same pipeline, tuned prompt for abstracts
- Falls back to "no AI available" gracefully if `ollama` isn't running —
  important for low-spec machines.

## 6. Package manager: `stud`

`stud` is a Rust CLI that is a *friendly wrapper*, not a new package format:

| Command | Underlying action |
|---|---|
| `stud search <name>` | `pacman -Ss <name>` + `flatpak search <name>`, merged output |
| `stud install <name>` | tries `pacman -S`, falls back to `flatpak install` |
| `stud remove <name>` | `pacman -Rns` / `flatpak uninstall` |
| `stud update` | `pacman -Syu && flatpak update` |

This gives students **one mental model** ("just use `stud`") while you keep
all the real package management correctness of pacman/Flatpak — you are not
maintaining your own repo of binaries (which would be a huge undertaking).

## 7. Desktop environment

- Base: GNOME (most polished, best accessibility, good docs for theming).
- Custom theme: dark, monochrome-leaning with one accent color — matches
  the visual language of your other study tools.
- Pre-installed GNOME Shell extensions: a simple dock, a "Study Mode" quick
  toggle (Do Not Disturb + blocks distracting app launches via a small
  GNOME extension you write).

## 8. Data model (SQLite, shared schema convention)

Every app stores its data in `~/.local/share/studentos/<app>.db`. Suggested
core tables for `studentos-notes`:

```sql
CREATE TABLE notes (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  body_markdown TEXT NOT NULL,
  tags TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE flashcards (
  id INTEGER PRIMARY KEY,
  deck TEXT NOT NULL,
  front TEXT NOT NULL,
  back TEXT NOT NULL,
  ease REAL DEFAULT 2.5,        -- SM-2 spaced repetition factor
  interval_days INTEGER DEFAULT 1,
  due_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE citations (
  id INTEGER PRIMARY KEY,
  bibtex_key TEXT UNIQUE,
  authors TEXT, title TEXT, year INTEGER,
  source_type TEXT,             -- article, book, website...
  raw_bibtex TEXT
);

CREATE TABLE assignments (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  course TEXT,
  due_at TEXT,
  status TEXT DEFAULT 'todo'    -- todo | in_progress | done
);
```
