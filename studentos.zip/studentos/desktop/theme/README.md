# StudentOS Desktop Theme

This folder holds branding assets copied into the ISO by
`scripts/build-iso.sh` (into `/usr/share/backgrounds/studentos/`).

## What to add here

- `wallpaper.png` — default desktop background (referenced by
  `build/archiso/customize_airootfs.sh` via dconf)
- A GTK theme (e.g. a recolored fork of **Orchis** or **WhiteSur-Dark**
  using the palette below) — install to
  `airootfs/usr/share/themes/StudentOS-Dark/`
- An icon theme — `airootfs/usr/share/icons/StudentOS-Icons/`

## Palette (matches `apps/studentos-notes/tailwind.config.js`)

| Token | Hex | Use |
|---|---|---|
| canvas | `#15161A` | window backgrounds |
| surface | `#1D1F25` | panels, cards |
| border | `#2C2F37` | hairlines |
| ink | `#E7E8EC` | primary text |
| muted | `#8B8F98` | secondary text |
| accent | `#D9A356` | highlights, focus, active states |

## Suggested fonts (install as packages, then set via dconf)

- UI: **Inter** (`ttf-inter` on Arch)
- Monospace: **JetBrains Mono** (`ttf-jetbrains-mono`)
- Reading/notes: **Source Serif 4** (`otf-source-serif-pro`)
