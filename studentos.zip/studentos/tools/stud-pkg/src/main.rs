//! `stud` — the StudentOS package manager CLI.
//!
//! This is intentionally a *thin wrapper*: it does not implement its own
//! package format or repository. Instead it gives students one consistent
//! command (`stud install/remove/update/search`) while delegating to the
//! real, battle-tested package managers already present on the system
//! (pacman on Arch-based StudentOS, apt as a fallback for Debian/Ubuntu
//! development machines) plus Flatpak for sandboxed GUI apps.
//!
//! Build:  cargo build --release
//! Run:    ./target/release/stud search neovim

use std::env;
use std::path::Path;
use std::process::{exit, Command, ExitStatus};

/// Which underlying native package manager is available on this system.
#[derive(Debug, Clone, Copy, PartialEq)]
enum Backend {
    Pacman, // Arch Linux — the StudentOS target distro
    Apt,    // Debian/Ubuntu — useful while developing on a dev VM
}

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() < 2 {
        print_usage();
        exit(1);
    }

    let backend = match detect_backend() {
        Some(b) => b,
        None => {
            eprintln!("stud: error: no supported package manager (pacman or apt) found.");
            eprintln!("       StudentOS expects to run on an Arch-based system.");
            exit(1);
        }
    };

    let command = args[1].as_str();
    let rest: Vec<String> = args[2..].to_vec();

    let status = match command {
        "search" | "s" => cmd_search(backend, &rest),
        "install" | "i" => cmd_install(backend, &rest),
        "remove" | "rm" | "r" => cmd_remove(backend, &rest),
        "update" | "up" => cmd_update(backend),
        "-h" | "--help" | "help" => {
            print_usage();
            return;
        }
        other => {
            eprintln!("stud: unknown command '{other}'");
            print_usage();
            exit(1);
        }
    };

    match status {
        Ok(s) if s.success() => {}
        Ok(s) => exit(s.code().unwrap_or(1)),
        Err(e) => {
            eprintln!("stud: failed to run command: {e}");
            exit(1);
        }
    }
}

fn print_usage() {
    println!("StudentOS package manager — stud");
    println!();
    println!("USAGE:");
    println!("    stud search <name>     Search for a package (native + Flatpak)");
    println!("    stud install <name>... Install one or more packages");
    println!("    stud remove <name>...  Remove one or more packages");
    println!("    stud update            Update all packages (system + Flatpak)");
    println!();
    println!("Aliases: s=search, i=install, rm/r=remove, up=update");
}

/// Detect which native package manager is installed by checking for the
/// binary on disk. We deliberately avoid relying on `which` so this works
/// even on a minimal system.
fn detect_backend() -> Option<Backend> {
    if Path::new("/usr/bin/pacman").exists() {
        Some(Backend::Pacman)
    } else if Path::new("/usr/bin/apt").exists() || Path::new("/usr/bin/apt-get").exists() {
        Some(Backend::Apt)
    } else {
        None
    }
}

/// True if Flatpak is available, used to supplement search/install/update.
fn has_flatpak() -> bool {
    Path::new("/usr/bin/flatpak").exists() || Path::new("/usr/local/bin/flatpak").exists()
}

/// Run a command, inheriting the parent's stdio so output/colors show up
/// normally and the user can answer interactive [y/N] prompts.
fn run(cmd: &str, args: &[&str]) -> std::io::Result<ExitStatus> {
    println!("stud: running `{cmd} {}`", args.join(" "));
    Command::new(cmd).args(args).status()
}

fn require_args(rest: &[String], usage: &str) {
    if rest.is_empty() {
        eprintln!("stud: missing package name(s)");
        eprintln!("usage: {usage}");
        exit(1);
    }
}

fn cmd_search(backend: Backend, rest: &[String]) -> std::io::Result<ExitStatus> {
    require_args(rest, "stud search <name>");
    let term = rest.join(" ");

    let native_status = match backend {
        Backend::Pacman => run("pacman", &["-Ss", &term])?,
        Backend::Apt => run("apt-cache", &["search", &term])?,
    };

    if has_flatpak() {
        println!();
        println!("-- Flatpak results --");
        let _ = run("flatpak", &["search", &term])?;
    }

    Ok(native_status)
}

fn cmd_install(backend: Backend, rest: &[String]) -> std::io::Result<ExitStatus> {
    require_args(rest, "stud install <name>...");
    let pkg_refs: Vec<&str> = rest.iter().map(String::as_str).collect();

    match backend {
        Backend::Pacman => {
            let mut args = vec!["-S", "--noconfirm"];
            args.extend(pkg_refs);
            run("sudo", &prefix("pacman", &args))
        }
        Backend::Apt => {
            let mut args = vec!["install", "-y"];
            args.extend(pkg_refs);
            run("sudo", &prefix("apt", &args))
        }
    }
}

fn cmd_remove(backend: Backend, rest: &[String]) -> std::io::Result<ExitStatus> {
    require_args(rest, "stud remove <name>...");
    let pkg_refs: Vec<&str> = rest.iter().map(String::as_str).collect();

    match backend {
        Backend::Pacman => {
            let mut args = vec!["-Rns", "--noconfirm"];
            args.extend(pkg_refs);
            run("sudo", &prefix("pacman", &args))
        }
        Backend::Apt => {
            let mut args = vec!["remove", "-y"];
            args.extend(pkg_refs);
            run("sudo", &prefix("apt", &args))
        }
    }
}

fn cmd_update(backend: Backend) -> std::io::Result<ExitStatus> {
    let native_status = match backend {
        Backend::Pacman => run("sudo", &["pacman", "-Syu", "--noconfirm"])?,
        Backend::Apt => {
            run("sudo", &["apt", "update"])?;
            run("sudo", &["apt", "upgrade", "-y"])?
        }
    };

    if has_flatpak() {
        let _ = run("flatpak", &["update", "-y"])?;
    }

    Ok(native_status)
}

/// Helper: prepend the real binary name so `sudo` runs `sudo pacman -S ...`
/// instead of `sudo -S ...`.
fn prefix<'a>(bin: &'a str, args: &[&'a str]) -> Vec<&'a str> {
    let mut v = vec![bin];
    v.extend_from_slice(args);
    v
}
