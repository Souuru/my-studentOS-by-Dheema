import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Tauri expects a fixed port; fail if it's taken instead of trying others.
  server: {
    port: 5173,
    strictPort: true,
  },
  // Tauri uses Chromium on Windows/Linux and WebKit on macOS.
  build: {
    target: ["es2021", "chrome100", "safari13"],
    minify: !process.env.TAURI_DEBUG ? "esbuild" : false,
    sourcemap: !!process.env.TAURI_DEBUG,
  },
});
