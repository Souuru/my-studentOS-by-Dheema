import React, { useState } from "react";
import NotesPanel from "./components/NotesPanel";
import FlashcardsPanel from "./components/FlashcardsPanel";
import PlannerPanel from "./components/PlannerPanel";

const TABS = [
  { id: "notes", label: "Notes" },
  { id: "flashcards", label: "Flashcards" },
  { id: "planner", label: "Planner" },
];

export default function App() {
  const [tab, setTab] = useState("notes");

  return (
    <div className="h-screen w-screen flex bg-canvas text-ink">
      {/* Nav rail */}
      <nav className="w-16 border-r border-border flex flex-col items-center py-4 gap-3">
        <div className="w-8 h-8 rounded-sm bg-accentSoft text-accent flex items-center justify-center text-xs font-bold mb-2">
          OS
        </div>
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            title={t.label}
            className={`w-10 h-10 rounded-md text-[10px] uppercase tracking-wide flex items-center justify-center border ${
              tab === t.id
                ? "border-accent text-accent bg-accentSoft"
                : "border-transparent text-muted hover:text-ink"
            }`}
          >
            {t.label.slice(0, 4)}
          </button>
        ))}
      </nav>

      {/* Active panel */}
      <div className="flex-1 min-w-0">
        {tab === "notes" && <NotesPanel />}
        {tab === "flashcards" && <FlashcardsPanel />}
        {tab === "planner" && <PlannerPanel />}
      </div>
    </div>
  );
}
