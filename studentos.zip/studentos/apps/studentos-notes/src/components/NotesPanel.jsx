import React, { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import { invoke } from "../lib/tauri";

export default function NotesPanel() {
  const [notes, setNotes] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [draft, setDraft] = useState({ title: "", body_markdown: "", tags: "" });
  const [preview, setPreview] = useState(true);

  useEffect(() => {
    invoke("list_notes").then((rows) => {
      setNotes(rows);
      if (rows.length) selectNote(rows[0]);
    });
  }, []);

  function selectNote(note) {
    setSelectedId(note.id);
    setDraft({ title: note.title, body_markdown: note.body_markdown, tags: note.tags || "" });
  }

  async function handleNew() {
    const created = await invoke("save_note", {
      id: null,
      title: "Untitled note",
      bodyMarkdown: "",
      tags: "",
    });
    setNotes((prev) => [created, ...prev]);
    selectNote(created);
  }

  async function handleSave() {
    if (!selectedId) return;
    await invoke("save_note", {
      id: selectedId,
      title: draft.title,
      bodyMarkdown: draft.body_markdown,
      tags: draft.tags,
    });
    setNotes((prev) =>
      prev.map((n) => (n.id === selectedId ? { ...n, ...draft } : n))
    );
  }

  async function handleDelete(id) {
    await invoke("delete_note", { id });
    setNotes((prev) => prev.filter((n) => n.id !== id));
    if (selectedId === id) {
      setSelectedId(null);
      setDraft({ title: "", body_markdown: "", tags: "" });
    }
  }

  return (
    <div className="flex h-full">
      {/* Note list */}
      <aside className="w-64 border-r border-border flex flex-col">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <h2 className="text-sm font-semibold text-muted uppercase tracking-wide">Notes</h2>
          <button
            onClick={handleNew}
            className="text-xs px-2 py-1 rounded-sm bg-accentSoft text-accent hover:bg-accent hover:text-canvas transition-colors"
          >
            + New
          </button>
        </div>
        <ul className="overflow-y-auto flex-1">
          {notes.map((n) => (
            <li
              key={n.id}
              onClick={() => selectNote(n)}
              className={`px-3 py-2 cursor-pointer border-b border-border/60 ${
                n.id === selectedId ? "bg-surface" : "hover:bg-surface/60"
              }`}
            >
              <div className="text-sm font-medium truncate">{n.title || "Untitled"}</div>
              {n.tags && (
                <div className="text-xs text-accent mt-0.5">#{n.tags}</div>
              )}
            </li>
          ))}
        </ul>
      </aside>

      {/* Editor + preview */}
      <main className="flex-1 flex flex-col">
        {selectedId ? (
          <>
            <div className="p-3 border-b border-border flex items-center gap-2">
              <input
                className="bg-transparent text-lg font-semibold flex-1 outline-none placeholder:text-muted"
                placeholder="Note title"
                value={draft.title}
                onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
                onBlur={handleSave}
              />
              <input
                className="bg-surface border border-border rounded-sm text-xs px-2 py-1 w-32 outline-none placeholder:text-muted"
                placeholder="tags"
                value={draft.tags}
                onChange={(e) => setDraft((d) => ({ ...d, tags: e.target.value }))}
                onBlur={handleSave}
              />
              <button
                onClick={() => setPreview((p) => !p)}
                className="text-xs px-2 py-1 rounded-sm border border-border text-muted hover:text-ink"
              >
                {preview ? "Edit" : "Preview"}
              </button>
              <button
                onClick={() => handleDelete(selectedId)}
                className="text-xs px-2 py-1 rounded-sm border border-border text-muted hover:text-red-400"
              >
                Delete
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {preview ? (
                <div className="prose-note max-w-2xl">
                  <ReactMarkdown>{draft.body_markdown || "*Nothing here yet — switch to Edit.*"}</ReactMarkdown>
                </div>
              ) : (
                <textarea
                  className="w-full h-full bg-transparent outline-none font-mono text-sm resize-none placeholder:text-muted"
                  placeholder="Write Markdown here..."
                  value={draft.body_markdown}
                  onChange={(e) => setDraft((d) => ({ ...d, body_markdown: e.target.value }))}
                  onBlur={handleSave}
                />
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted text-sm">
            Select a note, or create a new one.
          </div>
        )}
      </main>
    </div>
  );
}
