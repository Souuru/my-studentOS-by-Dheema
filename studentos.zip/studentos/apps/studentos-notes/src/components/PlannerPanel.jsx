import React, { useEffect, useMemo, useState } from "react";
import { invoke } from "../lib/tauri";

export default function PlannerPanel() {
  const [assignments, setAssignments] = useState([]);
  const [form, setForm] = useState({ title: "", course: "", due_at: "" });

  useEffect(() => {
    invoke("list_assignments").then(setAssignments);
  }, []);

  const sorted = useMemo(
    () =>
      [...assignments].sort(
        (a, b) => new Date(a.due_at) - new Date(b.due_at)
      ),
    [assignments]
  );

  async function addAssignment(e) {
    e.preventDefault();
    if (!form.title || !form.due_at) return;
    const created = await invoke("save_assignment", form);
    setAssignments((prev) => [...prev, created]);
    setForm({ title: "", course: "", due_at: "" });
  }

  function daysUntil(dateStr) {
    const ms = new Date(dateStr) - new Date();
    return Math.ceil(ms / (1000 * 60 * 60 * 24));
  }

  return (
    <div className="h-full flex flex-col">
      <form onSubmit={addAssignment} className="p-3 border-b border-border flex gap-2 flex-wrap">
        <input
          className="bg-surface border border-border rounded-sm px-2 py-1.5 text-sm flex-1 min-w-[160px] outline-none placeholder:text-muted"
          placeholder="Assignment title"
          value={form.title}
          onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
        />
        <input
          className="bg-surface border border-border rounded-sm px-2 py-1.5 text-sm w-32 outline-none placeholder:text-muted"
          placeholder="Course"
          value={form.course}
          onChange={(e) => setForm((f) => ({ ...f, course: e.target.value }))}
        />
        <input
          type="date"
          className="bg-surface border border-border rounded-sm px-2 py-1.5 text-sm outline-none"
          value={form.due_at}
          onChange={(e) => setForm((f) => ({ ...f, due_at: e.target.value }))}
        />
        <button className="px-3 py-1.5 rounded-sm bg-accentSoft text-accent text-sm hover:bg-accent hover:text-canvas transition-colors">
          Add
        </button>
      </form>

      <ul className="flex-1 overflow-y-auto p-3 space-y-2">
        {sorted.map((a) => {
          const days = daysUntil(a.due_at);
          const urgent = days <= 2;
          return (
            <li
              key={a.id}
              className="flex items-stretch bg-surface border border-border rounded-md overflow-hidden"
            >
              {/* "Stub" edge — perforation made with a repeating gradient */}
              <div
                className={`w-16 flex flex-col items-center justify-center text-xs font-mono border-r border-dashed border-border ${
                  urgent ? "text-accent" : "text-muted"
                }`}
              >
                <span className="text-lg font-semibold">
                  {days >= 0 ? days : 0}
                </span>
                <span>{days === 1 ? "day left" : "days left"}</span>
              </div>

              <div className="flex-1 px-3 py-2">
                <div className="text-sm font-medium">{a.title}</div>
                <div className="text-xs text-muted">
                  {a.course || "—"} · due {a.due_at}
                </div>
              </div>
            </li>
          );
        })}
        {sorted.length === 0 && (
          <p className="text-muted text-sm p-3">No assignments yet — add one above.</p>
        )}
      </ul>
    </div>
  );
}
