import React, { useEffect, useMemo, useState } from "react";
import { invoke } from "../lib/tauri";

export default function FlashcardsPanel() {
  const [cards, setCards] = useState([]);
  const [deck, setDeck] = useState(null);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);

  useEffect(() => {
    invoke("list_flashcards").then((rows) => {
      setCards(rows);
      if (rows.length) setDeck(rows[0].deck);
    });
  }, []);

  const decks = useMemo(() => [...new Set(cards.map((c) => c.deck))], [cards]);
  const deckCards = useMemo(() => cards.filter((c) => c.deck === deck), [cards, deck]);
  const current = deckCards[index];

  async function grade(g) {
    if (!current) return;
    await invoke("review_flashcard", { id: current.id, grade: g });
    setFlipped(false);
    setIndex((i) => (i + 1) % Math.max(deckCards.length, 1));
  }

  return (
    <div className="h-full flex flex-col">
      {/* Deck tabs */}
      <div className="border-b border-border p-3 flex gap-2 overflow-x-auto">
        {decks.map((d) => (
          <button
            key={d}
            onClick={() => {
              setDeck(d);
              setIndex(0);
              setFlipped(false);
            }}
            className={`text-xs px-3 py-1.5 rounded-sm border ${
              d === deck
                ? "border-accent text-accent bg-accentSoft"
                : "border-border text-muted hover:text-ink"
            }`}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Review area */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 gap-6">
        {current ? (
          <>
            <div className="text-xs text-muted">
              Card {index + 1} of {deckCards.length} · interval{" "}
              {current.interval_days}d · ease {current.ease.toFixed(2)}
            </div>

            {/* Flip card */}
            <button
              onClick={() => setFlipped((f) => !f)}
              className="w-full max-w-md aspect-[3/2] rounded-md border border-border bg-surface
                         flex items-center justify-center p-6 text-center
                         transition-transform duration-300"
              style={{
                transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
                transformStyle: "preserve-3d",
              }}
            >
              <span
                className="text-lg leading-relaxed"
                style={{ transform: flipped ? "rotateY(180deg)" : "none" }}
              >
                {flipped ? current.back : current.front}
              </span>
            </button>

            <p className="text-xs text-muted">
              {flipped ? "How well did you know this?" : "Click the card to reveal the answer"}
            </p>

            {flipped && (
              <div className="flex gap-3">
                <GradeButton label="Hard" onClick={() => grade("hard")} />
                <GradeButton label="Good" onClick={() => grade("good")} accent />
                <GradeButton label="Easy" onClick={() => grade("easy")} />
              </div>
            )}
          </>
        ) : (
          <p className="text-muted text-sm">No cards in this deck yet.</p>
        )}
      </div>
    </div>
  );
}

function GradeButton({ label, onClick, accent }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-sm text-sm border transition-colors ${
        accent
          ? "border-accent text-accent hover:bg-accent hover:text-canvas"
          : "border-border text-muted hover:text-ink"
      }`}
    >
      {label}
    </button>
  );
}
