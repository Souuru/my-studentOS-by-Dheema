# studentos-notes

The flagship StudentOS productivity app: Markdown notes, flashcards
(spaced repetition), and an assignment/study planner — all stored locally
in SQLite. Built with **Tauri** (Rust backend) + **React** (frontend).

## This is a *starter*, not a finished app

The files here are real, working source code meant as a foundation —
enough to run, see your notes persist in SQLite, and build on. You will
extend it during Phase 4 of `docs/TEACHING_GUIDE_TH.md`.

## Setup (on your dev machine, needs internet for `npm`/`cargo` deps)

```bash
# 1. Scaffold (only needed once, to generate the parts not included here
#    like vite config / tauri.conf.json — or merge these files into a repo
#    created by `npm create tauri-app@latest`)
npm create tauri-app@latest studentos-notes -- --template react

# 2. Copy the files from this folder into the generated project,
#    overwriting src/App.jsx, src/main.jsx, src/index.css,
#    src-tauri/src/main.rs, src-tauri/Cargo.toml, tailwind.config.js

# 3. Install JS deps + Tailwind + the markdown renderer
cd studentos-notes
npm install
npm install -D tailwindcss postcss autoprefixer
npm install react-markdown

# 4. Add rusqlite to the Rust side
cd src-tauri
cargo add rusqlite --features bundled

# 5. Run in dev mode
cd ..
npm run tauri dev
```

## What's implemented in this starter

- **Notes tab**: create/edit/delete Markdown notes, live preview, tags.
- **Flashcards tab**: create decks + cards, "Review" mode with a simple
  SM-2-style spaced-repetition scheduler.
- **Planner tab**: assignment list with due dates, sorted by urgency.
- Rust backend (`src-tauri/src/main.rs`) exposes Tauri *commands* that run
  SQL against `~/.local/share/studentos/notes.db` using `rusqlite`.

## What you'll add next (see TEACHING_GUIDE_TH.md Phase 4–5)

- Citation manager tab (BibTeX export)
- PDF reader tab (pdf.js)
- "Ask AI" button that calls `http://localhost:11434` (ollama)
