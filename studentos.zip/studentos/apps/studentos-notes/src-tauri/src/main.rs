// src-tauri/src/main.rs
//
// StudentOS Notes — Tauri backend. Exposes commands consumed by the React
// frontend (see ../src/lib/tauri.js). All data lives in a single SQLite
// database at ~/.local/share/studentos/notes.db (created automatically).

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use rusqlite::{params, Connection};
use serde::Serialize;
use std::path::PathBuf;
use std::sync::Mutex;
use tauri::State;

struct Db(Mutex<Connection>);

// ---------------------------------------------------------------------
// Data models — these shapes are sent to React as JSON
// ---------------------------------------------------------------------

#[derive(Serialize)]
struct Note {
    id: i64,
    title: String,
    body_markdown: String,
    tags: Option<String>,
}

#[derive(Serialize)]
struct Flashcard {
    id: i64,
    deck: String,
    front: String,
    back: String,
    ease: f64,
    interval_days: i64,
}

#[derive(Serialize)]
struct Assignment {
    id: i64,
    title: String,
    course: Option<String>,
    due_at: String,
    status: String,
}

// ---------------------------------------------------------------------
// Database setup
// ---------------------------------------------------------------------

fn db_path() -> PathBuf {
    let mut dir = dirs::data_dir().expect("could not determine data directory");
    dir.push("studentos");
    std::fs::create_dir_all(&dir).expect("failed to create data directory");
    dir.push("notes.db");
    dir
}

fn init_db() -> rusqlite::Result<Connection> {
    let conn = Connection::open(db_path())?;

    conn.execute_batch(
        "
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body_markdown TEXT NOT NULL DEFAULT '',
            tags TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS flashcards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            deck TEXT NOT NULL,
            front TEXT NOT NULL,
            back TEXT NOT NULL,
            ease REAL NOT NULL DEFAULT 2.5,
            interval_days INTEGER NOT NULL DEFAULT 1,
            due_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            course TEXT,
            due_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'todo'
        );
        ",
    )?;

    // Seed a starter deck the first time the database is created.
    let count: i64 = conn.query_row("SELECT COUNT(*) FROM flashcards", [], |r| r.get(0))?;
    if count == 0 {
        conn.execute(
            "INSERT INTO flashcards (deck, front, back) VALUES (?1, ?2, ?3)",
            params!["Calculus", "d/dx [x^n] = ?", "n*x^(n-1)"],
        )?;
        conn.execute(
            "INSERT INTO flashcards (deck, front, back) VALUES (?1, ?2, ?3)",
            params!["Calculus", "Integral of x dx = ?", "x^2/2 + C"],
        )?;
    }

    Ok(conn)
}

// ---------------------------------------------------------------------
// Notes commands
// ---------------------------------------------------------------------

#[tauri::command]
fn list_notes(db: State<Db>) -> Result<Vec<Note>, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, title, body_markdown, tags FROM notes ORDER BY updated_at DESC")
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |row| {
            Ok(Note {
                id: row.get(0)?,
                title: row.get(1)?,
                body_markdown: row.get(2)?,
                tags: row.get(3)?,
            })
        })
        .map_err(|e| e.to_string())?;

    rows.collect::<Result<Vec<_>, _>>().map_err(|e| e.to_string())
}

#[tauri::command]
fn save_note(
    db: State<Db>,
    id: Option<i64>,
    title: String,
    body_markdown: String,
    tags: String,
) -> Result<Note, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;

    let new_id = match id {
        Some(existing_id) => {
            conn.execute(
                "UPDATE notes SET title = ?1, body_markdown = ?2, tags = ?3,
                 updated_at = datetime('now') WHERE id = ?4",
                params![title, body_markdown, tags, existing_id],
            )
            .map_err(|e| e.to_string())?;
            existing_id
        }
        None => {
            conn.execute(
                "INSERT INTO notes (title, body_markdown, tags) VALUES (?1, ?2, ?3)",
                params![title, body_markdown, tags],
            )
            .map_err(|e| e.to_string())?;
            conn.last_insert_rowid()
        }
    };

    Ok(Note {
        id: new_id,
        title,
        body_markdown,
        tags: Some(tags),
    })
}

#[tauri::command]
fn delete_note(db: State<Db>, id: i64) -> Result<(), String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM notes WHERE id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

// ---------------------------------------------------------------------
// Flashcards commands
// ---------------------------------------------------------------------

#[tauri::command]
fn list_flashcards(db: State<Db>) -> Result<Vec<Flashcard>, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, deck, front, back, ease, interval_days FROM flashcards ORDER BY deck, id")
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |row| {
            Ok(Flashcard {
                id: row.get(0)?,
                deck: row.get(1)?,
                front: row.get(2)?,
                back: row.get(3)?,
                ease: row.get(4)?,
                interval_days: row.get(5)?,
            })
        })
        .map_err(|e| e.to_string())?;

    rows.collect::<Result<Vec<_>, _>>().map_err(|e| e.to_string())
}

/// Very small SM-2-inspired update: "hard" lowers the ease factor and resets
/// the interval, "good"/"easy" grow the interval by the ease factor.
#[tauri::command]
fn review_flashcard(db: State<Db>, id: i64, grade: String) -> Result<Flashcard, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;

    let (mut ease, mut interval): (f64, i64) = conn
        .query_row(
            "SELECT ease, interval_days FROM flashcards WHERE id = ?1",
            params![id],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .map_err(|e| e.to_string())?;

    match grade.as_str() {
        "hard" => {
            ease = (ease - 0.2).max(1.3);
            interval = 1;
        }
        "easy" => {
            ease += 0.15;
            interval = ((interval as f64) * ease).round() as i64;
        }
        _ /* "good" */ => {
            interval = ((interval as f64) * ease).round().max(1.0) as i64;
        }
    }

    conn.execute(
        "UPDATE flashcards SET ease = ?1, interval_days = ?2,
         due_at = datetime('now', '+' || ?2 || ' days') WHERE id = ?3",
        params![ease, interval, id],
    )
    .map_err(|e| e.to_string())?;

    let (deck, front, back): (String, String, String) = conn
        .query_row(
            "SELECT deck, front, back FROM flashcards WHERE id = ?1",
            params![id],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
        )
        .map_err(|e| e.to_string())?;

    Ok(Flashcard { id, deck, front, back, ease, interval_days: interval })
}

// ---------------------------------------------------------------------
// Assignments / planner commands
// ---------------------------------------------------------------------

#[tauri::command]
fn list_assignments(db: State<Db>) -> Result<Vec<Assignment>, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, title, course, due_at, status FROM assignments ORDER BY due_at")
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |row| {
            Ok(Assignment {
                id: row.get(0)?,
                title: row.get(1)?,
                course: row.get(2)?,
                due_at: row.get(3)?,
                status: row.get(4)?,
            })
        })
        .map_err(|e| e.to_string())?;

    rows.collect::<Result<Vec<_>, _>>().map_err(|e| e.to_string())
}

#[tauri::command]
fn save_assignment(
    db: State<Db>,
    title: String,
    course: Option<String>,
    due_at: String,
) -> Result<Assignment, String> {
    let conn = db.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO assignments (title, course, due_at) VALUES (?1, ?2, ?3)",
        params![title, course, due_at],
    )
    .map_err(|e| e.to_string())?;

    Ok(Assignment {
        id: conn.last_insert_rowid(),
        title,
        course,
        due_at,
        status: "todo".to_string(),
    })
}

// ---------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------

fn main() {
    let conn = init_db().expect("failed to initialize StudentOS database");

    tauri::Builder::default()
        .manage(Db(Mutex::new(conn)))
        .invoke_handler(tauri::generate_handler![
            list_notes,
            save_note,
            delete_note,
            list_flashcards,
            review_flashcard,
            list_assignments,
            save_assignment
        ])
        .run(tauri::generate_context!())
        .expect("error while running StudentOS Notes");
}
