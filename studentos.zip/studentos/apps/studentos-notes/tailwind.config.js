/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // StudentOS dark, near-monochrome palette with one warm accent
        canvas: "#15161A",   // app background
        surface: "#1D1F25",  // cards / panels
        border: "#2C2F37",   // hairlines
        ink: "#E7E8EC",      // primary text
        muted: "#8B8F98",    // secondary text
        accent: "#D9A356",   // warm "highlighter" amber — the one accent
        accentSoft: "#3A3220" // accent used as a subtle background tint
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui"],
        serif: ["Source Serif 4", "Georgia", "serif"],
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular"]
      },
      borderRadius: {
        sm: "4px",
        md: "8px"
      }
    }
  },
  plugins: []
};
