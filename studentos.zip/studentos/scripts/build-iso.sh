#!/usr/bin/env bash
# scripts/build-iso.sh
#
# Builds the StudentOS .iso. MUST be run on a real Arch Linux machine
# (or an Arch Linux VM) with the 'archiso' package installed and root
# privileges. This script does NOT run inside this chat sandbox — copy this
# repo to your Arch build VM first.
#
# Usage:
#   sudo ./scripts/build-iso.sh

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROFILE_DIR="$ROOT_DIR/build/archiso"
WORK_DIR="$ROOT_DIR/build/_work"
OUT_DIR="$ROOT_DIR/build/_out"

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root (sudo)." >&2
  exit 1
fi

if ! command -v mkarchiso >/dev/null; then
  echo "mkarchiso not found. Install with: sudo pacman -S archiso" >&2
  exit 1
fi

echo "==> Preparing archiso profile from releng base"
PROFILE_BUILD_DIR="$ROOT_DIR/build/_profile"
rm -rf "$PROFILE_BUILD_DIR"
cp -r /usr/share/archiso/configs/releng/ "$PROFILE_BUILD_DIR"

echo "==> Merging StudentOS package list"
cat "$PROFILE_DIR/packages.x86_64" >> "$PROFILE_BUILD_DIR/packages.x86_64"

echo "==> Copying StudentOS customization script"
mkdir -p "$PROFILE_BUILD_DIR/airootfs/root"
cp "$PROFILE_DIR/customize_airootfs.sh" "$PROFILE_BUILD_DIR/airootfs/root/customize_airootfs.sh"
chmod +x "$PROFILE_BUILD_DIR/airootfs/root/customize_airootfs.sh"

echo "==> Copying StudentOS binaries (stud-pkg, apps) into the image"
mkdir -p "$PROFILE_BUILD_DIR/airootfs/usr/local/bin"
if [[ -f "$ROOT_DIR/tools/stud-pkg/target/release/stud" ]]; then
  cp "$ROOT_DIR/tools/stud-pkg/target/release/stud" \
     "$PROFILE_BUILD_DIR/airootfs/usr/local/bin/stud"
else
  echo "    (!) stud binary not built yet — run:"
  echo "        cd tools/stud-pkg && cargo build --release"
fi

echo "==> Copying wallpaper / theme assets"
mkdir -p "$PROFILE_BUILD_DIR/airootfs/usr/share/backgrounds/studentos"
cp -r "$ROOT_DIR/desktop/theme/." \
      "$PROFILE_BUILD_DIR/airootfs/usr/share/backgrounds/studentos/" 2>/dev/null || true

echo "==> Running mkarchiso (this takes a while, needs several GB free)"
mkarchiso -v -w "$WORK_DIR" -o "$OUT_DIR" "$PROFILE_BUILD_DIR"

echo "==> Done. ISO is in: $OUT_DIR"
ls -lh "$OUT_DIR"
